/*
 * Generic queue implementation.
 */
#include "queue.h"
#include <stdlib.h>

queue* queue_new() {
    return NULL;
}

int queue_enqueue(queue* queue, void* item) {
    return -1;
}

int queue_dequeue(queue* queue, void** item) {
    return -1;
}

int queue_iterate(queue* queue, queue_func f, void* arg) {
    return -1;
}

int queue_free(queue* queue) {
    return -1;
}

int queue_length(const queue* queue) {
    return -1;
}

int queue_delete(queue* queue, void* item) {
    return -1;
}